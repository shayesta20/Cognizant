using System;
using System.Threading;
using System.Windows.Forms;
using Confluent.Kafka;

namespace KafkaChatWinForms
{
    // Hands-on 6.2: Create a Chat Application using C# Windows Application
    // using Kafka and consume the message in different client applications.
    // Run multiple instances of this app - each one both publishes and
    // subscribes to the same topic, simulating different chat clients.
    public partial class Form1 : Form
    {
        private const string BootstrapServers = "localhost:9092";
        private const string Topic = "chat-messages";

        private IProducer<Null, string> _producer;
        private IConsumer<Ignore, string> _consumer;
        private Thread _consumerThread;
        private CancellationTokenSource _cts;
        private string _userName;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            _userName = string.IsNullOrWhiteSpace(txtUserName.Text) ? "Guest" : txtUserName.Text.Trim();

            var producerConfig = new ProducerConfig { BootstrapServers = BootstrapServers };
            _producer = new ProducerBuilder<Null, string>(producerConfig).Build();

            var consumerConfig = new ConsumerConfig
            {
                BootstrapServers = BootstrapServers,
                GroupId = $"winforms-chat-{Guid.NewGuid()}", // unique group per client so every client sees every message
                AutoOffsetReset = AutoOffsetReset.Latest
            };
            _consumer = new ConsumerBuilder<Ignore, string>(consumerConfig).Build();
            _consumer.Subscribe(Topic);

            _cts = new CancellationTokenSource();
            _consumerThread = new Thread(() => ConsumeLoop(_cts.Token)) { IsBackground = true };
            _consumerThread.Start();

            btnConnect.Enabled = false;
            txtUserName.Enabled = false;
            AppendToLog($"Connected as '{_userName}' to topic '{Topic}'.");
        }

        private void ConsumeLoop(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        var result = _consumer.Consume(TimeSpan.FromSeconds(1));
                        if (result != null)
                        {
                            AppendToLog(result.Message.Value);
                        }
                    }
                    catch (ConsumeException ex)
                    {
                        AppendToLog($"[Consume error] {ex.Error.Reason}");
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // expected on shutdown
            }
            finally
            {
                _consumer.Close();
            }
        }

        private void AppendToLog(string text)
        {
            if (txtChatLog.InvokeRequired)
            {
                txtChatLog.Invoke(new Action(() => AppendToLog(text)));
                return;
            }

            txtChatLog.AppendText(text + Environment.NewLine);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            SendMessage();
        }

        private void txtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SendMessage();
            }
        }

        private async void SendMessage()
        {
            if (_producer == null)
            {
                MessageBox.Show("Please connect first.");
                return;
            }

            string message = txtMessage.Text.Trim();
            if (string.IsNullOrEmpty(message))
            {
                return;
            }

            try
            {
                string payload = $"{_userName}: {message}";
                await _producer.ProduceAsync(Topic, new Message<Null, string> { Value = payload });
                txtMessage.Clear();
            }
            catch (ProduceException<Null, string> ex)
            {
                AppendToLog($"[Send error] {ex.Error.Reason}");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _cts?.Cancel();
            _consumerThread?.Join(1500);
            _producer?.Dispose();
        }
    }
}
