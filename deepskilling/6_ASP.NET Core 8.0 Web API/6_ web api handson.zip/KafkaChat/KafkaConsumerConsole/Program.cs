using System;
using System.Threading;
using Confluent.Kafka;

namespace KafkaConsumerConsole
{
    // Hands-on 6.1: Consume the chat messages in the command prompt.
    // This is the SUBSCRIBER side - run alongside KafkaProducerConsole.
    class Program
    {
        private const string BootstrapServers = "localhost:9092";
        private const string Topic = "chat-messages";
        private const string GroupId = "chat-console-group";

        static void Main(string[] args)
        {
            var config = new ConsumerConfig
            {
                BootstrapServers = BootstrapServers,
                GroupId = GroupId,
                AutoOffsetReset = AutoOffsetReset.Latest
            };

            Console.WriteLine("=== Kafka Chat Subscriber ===");
            Console.WriteLine($"Broker : {BootstrapServers}");
            Console.WriteLine($"Topic  : {Topic}");
            Console.WriteLine("Listening for messages... Press Ctrl+C to exit.");

            using (var consumer = new ConsumerBuilder<Ignore, string>(config).Build())
            {
                consumer.Subscribe(Topic);

                bool cancelled = false;
                Console.CancelKeyPress += (_, e) =>
                {
                    e.Cancel = true;
                    cancelled = true;
                };

                try
                {
                    while (!cancelled)
                    {
                        try
                        {
                            var consumeResult = consumer.Consume(TimeSpan.FromSeconds(1));
                            if (consumeResult != null)
                            {
                                Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] {consumeResult.Message.Value}");
                            }
                        }
                        catch (ConsumeException ex)
                        {
                            Console.WriteLine($"Consume error: {ex.Error.Reason}");
                        }
                    }
                }
                finally
                {
                    consumer.Close();
                }
            }

            Console.WriteLine("Subscriber closed.");
        }
    }
}
