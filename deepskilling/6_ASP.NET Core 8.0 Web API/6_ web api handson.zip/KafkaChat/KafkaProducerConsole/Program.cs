using System;
using System.Threading.Tasks;
using Confluent.Kafka;

namespace KafkaProducerConsole
{
    // Hands-on 6.1: Create a Chat Application which uses Kafka as a streaming
    // platform and consume the chat messages in the command prompt.
    // This is the PUBLISHER side - run alongside KafkaConsumerConsole.
    class Program
    {
        private const string BootstrapServers = "localhost:9092";
        private const string Topic = "chat-messages";

        static async Task Main(string[] args)
        {
            var config = new ProducerConfig
            {
                BootstrapServers = BootstrapServers
            };

            Console.WriteLine("=== Kafka Chat Publisher ===");
            Console.WriteLine($"Broker : {BootstrapServers}");
            Console.WriteLine($"Topic  : {Topic}");
            Console.Write("Enter your name: ");
            string userName = Console.ReadLine();

            using (var producer = new ProducerBuilder<Null, string>(config).Build())
            {
                Console.WriteLine("Type a message and press Enter to send. Type 'exit' to quit.");

                while (true)
                {
                    Console.Write($"{userName}> ");
                    string message = Console.ReadLine();

                    if (string.Equals(message, "exit", StringComparison.OrdinalIgnoreCase))
                    {
                        break;
                    }

                    try
                    {
                        string payload = $"{userName}: {message}";
                        var deliveryResult = await producer.ProduceAsync(
                            Topic,
                            new Message<Null, string> { Value = payload });

                        Console.WriteLine($"  [sent to {deliveryResult.TopicPartitionOffset}]");
                    }
                    catch (ProduceException<Null, string> ex)
                    {
                        Console.WriteLine($"  Delivery failed: {ex.Error.Reason}");
                    }
                }
            }

            Console.WriteLine("Publisher closed.");
        }
    }
}
