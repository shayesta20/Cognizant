using System;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace WebApiHandson.Filters
{
    // Hands-on 3: Custom Exception filter
    // Catches exceptions occurring in the application, logs them to a file
    // and returns a 500 Internal Server Error result.
    public class CustomExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            var exception = context.Exception;

            // Capture exception detail and write it to a file in the system
            string logPath = Path.Combine(AppContext.BaseDirectory, "exception_log.txt");
            string logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {exception.Message}{Environment.NewLine}{exception.StackTrace}{Environment.NewLine}{new string('-', 60)}{Environment.NewLine}";

            try
            {
                File.AppendAllText(logPath, logEntry);
            }
            catch
            {
                // Swallow logging failures so they don't mask the original exception handling
            }

            context.Result = new ObjectResult(new
            {
                Message = "An unexpected error occurred.",
                Detail = exception.Message
            })
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };

            context.ExceptionHandled = true;
        }
    }
}
