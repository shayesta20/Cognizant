using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiHandson.Models;

namespace WebApiHandson.Controllers
{
    // Hands-on 2.3: Controller name in the Route attribute changed to 'Emp'
    [Route("api/Emp")]
    [ApiController]
    // Hands-on 5.4: Authorize attribute with roles POC and Admin
    [Authorize(Roles = "POC,Admin")]
    public class EmployeeController : ControllerBase
    {
        private readonly List<Employee> _employees;

        public EmployeeController()
        {
            _employees = GetStandardEmployeeList();
        }

        // Hands-on 3.1: Create a Private method GetStandardEmployeeList
        private List<Employee> GetStandardEmployeeList()
        {
            return new List<Employee>
            {
                new Employee
                {
                    Id = 1,
                    Name = "Alice",
                    Salary = 55000,
                    Permanent = true,
                    Department = new Department { Id = 1, Name = "Engineering" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 1, Name = "C#" },
                        new Skill { Id = 2, Name = "ASP.NET Core" }
                    },
                    DateOfBirth = new DateTime(1990, 5, 12)
                },
                new Employee
                {
                    Id = 2,
                    Name = "Bob",
                    Salary = 48000,
                    Permanent = false,
                    Department = new Department { Id = 2, Name = "QA" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 3, Name = "Manual Testing" }
                    },
                    DateOfBirth = new DateTime(1988, 11, 3)
                },
                new Employee
                {
                    Id = 3,
                    Name = "Charlie",
                    Salary = 62000,
                    Permanent = true,
                    Department = new Department { Id = 1, Name = "Engineering" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 1, Name = "C#" },
                        new Skill { Id = 4, Name = "Kafka" }
                    },
                    DateOfBirth = new DateTime(1992, 2, 20)
                }
            };
        }

        // Hands-on 3.1: GET action method returning List<Employee>
        // GET api/emp
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(200)]
        public ActionResult<List<Employee>> GetStandrad()
        {
            return Ok(_employees);
        }

        // Hands-on 3.3: Demonstrate the Custom Exception filter
        // GET api/emp/error
        [HttpGet("error")]
        [AllowAnonymous]
        [ProducesResponseType(500)]
        public ActionResult<Employee> GetWithException()
        {
            throw new Exception("Sample exception thrown to test CustomExceptionFilter");
        }

        // Hands-on 3.2: Use FromBody attribute to read the model object
        // POST api/emp
        [HttpPost]
        [ProducesResponseType(200)]
        public ActionResult<Employee> Post([FromBody] Employee employee)
        {
            employee.Id = _employees.Any() ? _employees.Max(e => e.Id) + 1 : 1;
            _employees.Add(employee);
            return Ok(employee);
        }

        // Hands-on 4: Web Api CRUD operation - PUT action method
        // PUT api/emp/5
        [HttpPut("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public ActionResult<Employee> Put(int id, [FromBody] Employee employee)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid employee id");
            }

            var existing = _employees.FirstOrDefault(e => e.Id == id);
            if (existing == null)
            {
                return BadRequest("Invalid employee id");
            }

            // Update the hardcoded list using the JSON data from the input body
            existing.Name = employee.Name;
            existing.Salary = employee.Salary;
            existing.Permanent = employee.Permanent;
            existing.Department = employee.Department;
            existing.Skills = employee.Skills;
            existing.DateOfBirth = employee.DateOfBirth;

            // Filter the employee list data for the input id and return that as output
            var updated = _employees.FirstOrDefault(e => e.Id == id);
            return Ok(updated);
        }

        // DELETE api/emp/5
        [HttpDelete("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public ActionResult Delete(int id)
        {
            var existing = _employees.FirstOrDefault(e => e.Id == id);
            if (id <= 0 || existing == null)
            {
                return BadRequest("Invalid employee id");
            }

            _employees.Remove(existing);
            return Ok();
        }
    }
}
