using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace WebApiHandson.Controllers
{
    // Hands-on 5: JsonWebToken
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class AuthController : ControllerBase
    {
        // GET api/auth
        // Invoke GenerateJSONWebToken sending a user id and 'Admin' role
        [HttpGet]
        [ProducesResponseType(200)]
        public ActionResult<string> Get()
        {
            string token = GenerateJSONWebToken(1, "Admin");
            return Ok(token);
        }

        // GET api/auth/poc
        // Generates a token with the 'POC' role - useful to test role based Authorize
        [HttpGet("poc")]
        [ProducesResponseType(200)]
        public ActionResult<string> GetPocToken()
        {
            string token = GenerateJSONWebToken(2, "POC");
            return Ok(token);
        }

        private string GenerateJSONWebToken(int userId, string userRole)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Startup.SecurityKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Role, userRole),
                new Claim("UserId", userId.ToString())
            };

            var token = new JwtSecurityToken(
                issuer: Startup.Issuer,
                audience: Startup.Audience,
                claims: claims,
                // Hands-on 5.3: Check for JWT expiration - set to 2 minutes to test expiry
                expires: DateTime.Now.AddMinutes(2),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
