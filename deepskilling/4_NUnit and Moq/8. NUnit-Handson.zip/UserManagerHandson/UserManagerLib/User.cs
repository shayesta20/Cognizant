namespace UserManagerLib
{
    /// <summary>
    /// Represents a user with a mandatory 10-character PAN Card number.
    /// </summary>
    public class User
    {
        public string PANCardNo { get; set; } = string.Empty;
    }
}
