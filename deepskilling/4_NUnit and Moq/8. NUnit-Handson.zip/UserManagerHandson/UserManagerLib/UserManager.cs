using System;

namespace UserManagerLib
{
    /// <summary>
    /// Handles creation of users.
    /// PANCardNo is a mandatory property and must be exactly 10 characters long.
    /// </summary>
    public class UserManager
    {
        /// <summary>
        /// Creates a new user for the given PAN Card number.
        /// </summary>
        /// <param name="panCardNo">Must be exactly 10 characters long.</param>
        /// <exception cref="NullReferenceException">Thrown when the input value is null or empty.</exception>
        /// <exception cref="FormatException">Thrown when the input string does not meet the length criteria (10 characters).</exception>
        public User CreateUser(string panCardNo)
        {
            if (string.IsNullOrEmpty(panCardNo))
            {
                throw new NullReferenceException("PANCardNo cannot be null or empty.");
            }

            if (panCardNo.Length != 10)
            {
                throw new FormatException("PANCardNo must be exactly 10 characters long.");
            }

            return new User { PANCardNo = panCardNo };
        }
    }
}
