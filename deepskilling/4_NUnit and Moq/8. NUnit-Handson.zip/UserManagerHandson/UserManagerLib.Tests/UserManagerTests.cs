using System;
using NUnit.Framework;
using UserManagerLib;

namespace UserManagerLib.Tests
{
    [TestFixture]
    public class UserManagerTests
    {
        private UserManager _userManager;

        [SetUp]
        public void SetUp()
        {
            _userManager = new UserManager();
        }

        // --- Happy path ---

        [Test]
        public void CreateUser_ValidTenCharacterPANCardNo_ReturnsUserWithPANCardNo()
        {
            User result = _userManager.CreateUser("ABCDE1234F");

            Assert.That(result.PANCardNo, Is.EqualTo("ABCDE1234F"));
        }

        // --- NullReferenceException scenarios: null or empty input ---

        [Test]
        public void CreateUser_NullPANCardNo_ThrowsNullReferenceException()
        {
            Assert.That(() => _userManager.CreateUser(null!), Throws.TypeOf<NullReferenceException>());
        }

        [Test]
        public void CreateUser_EmptyPANCardNo_ThrowsNullReferenceException()
        {
            Assert.That(() => _userManager.CreateUser(string.Empty), Throws.TypeOf<NullReferenceException>());
        }

        // --- FormatException scenarios: length criteria not met ---

        [Test]
        public void CreateUser_PANCardNoShorterThanTenCharacters_ThrowsFormatException()
        {
            Assert.That(() => _userManager.CreateUser("ABC123"), Throws.TypeOf<FormatException>());
        }

        [Test]
        public void CreateUser_PANCardNoLongerThanTenCharacters_ThrowsFormatException()
        {
            Assert.That(() => _userManager.CreateUser("ABCDE1234FGH"), Throws.TypeOf<FormatException>());
        }
    }
}
