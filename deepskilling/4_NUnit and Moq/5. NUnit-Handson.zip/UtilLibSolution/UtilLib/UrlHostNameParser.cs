using System;

namespace UtilLib
{
    /// <summary>
    /// Pulls the host name out of a URL string.
    /// </summary>
    public class UrlHostNameParser
    {
        /// <summary>
        /// Returns the host name portion of a URL.
        /// Handles two cases:
        ///   1) URL contains a scheme, e.g. "https://www.example.com/path"
        ///   2) URL has no scheme, e.g. "www.example.com/path"
        /// Port numbers and trailing paths are stripped from the result.
        /// </summary>
        public string ParseHostName(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                throw new ArgumentException("url cannot be null or empty", nameof(url));

            string working;

            int schemeIndex = url.IndexOf("://", StringComparison.Ordinal);
            if (schemeIndex >= 0)
            {
                // Path 1: URL includes a scheme (http://, https://, ftp:// ...)
                working = url.Substring(schemeIndex + 3);
            }
            else
            {
                // Path 2: no scheme present, url starts directly with the host
                working = url;
            }

            // Strip anything after the host: path ("/"), query ("?"), or port (":")
            int cutIndex = working.IndexOfAny(new[] { '/', ':', '?' });

            string hostName = cutIndex >= 0 ? working.Substring(0, cutIndex) : working;

            return hostName;
        }
    }
}
