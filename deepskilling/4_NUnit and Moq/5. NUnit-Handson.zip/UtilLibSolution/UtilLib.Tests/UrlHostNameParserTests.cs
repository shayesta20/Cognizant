using NUnit.Framework;
using UtilLib;

namespace UtilLib.Tests
{
    [TestFixture]
    public class UrlHostNameParserTests
    {
        private UrlHostNameParser _parser;

        [SetUp]
        public void SetUp()
        {
            _parser = new UrlHostNameParser();
        }

        // ---------- Path 1: URL contains a scheme ("://") ----------

        [Test]
        public void ParseHostName_UrlWithHttpScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("http://www.example.com/path/page.html");

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithHttpsScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("https://www.google.com/search?q=nunit");

            Assert.That(result, Is.EqualTo("www.google.com"));
        }

        [Test]
        public void ParseHostName_UrlWithSchemeAndPort_ReturnsHostNameWithoutPort()
        {
            string result = _parser.ParseHostName("https://api.example.com:8080/v1/users");

            Assert.That(result, Is.EqualTo("api.example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithSchemeNoPath_ReturnsHostName()
        {
            string result = _parser.ParseHostName("http://example.com");

            Assert.That(result, Is.EqualTo("example.com"));
        }

        [Test]
        public void ParseHostName_FtpUrl_ReturnsHostName()
        {
            string result = _parser.ParseHostName("ftp://files.example.com/downloads/file.zip");

            Assert.That(result, Is.EqualTo("files.example.com"));
        }

        // ---------- Path 2: URL has no scheme ----------

        [Test]
        public void ParseHostName_UrlWithoutScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("www.example.com/path/page.html");

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_HostOnlyNoPathNoScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("example.com");

            Assert.That(result, Is.EqualTo("example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithoutSchemeWithPort_ReturnsHostNameWithoutPort()
        {
            string result = _parser.ParseHostName("localhost:5000/api/values");

            Assert.That(result, Is.EqualTo("localhost"));
        }

        // ---------- Edge cases ----------

        [Test]
        public void ParseHostName_NullUrl_ThrowsArgumentException()
        {
            Assert.That(() => _parser.ParseHostName(null), Throws.ArgumentException);
        }

        [Test]
        public void ParseHostName_EmptyUrl_ThrowsArgumentException()
        {
            Assert.That(() => _parser.ParseHostName(string.Empty), Throws.ArgumentException);
        }
    }
}
