namespace ConverterLib
{
    /// <summary>
    /// Represents an external service that supplies the current USD -&gt; EUR exchange rate.
    /// The real implementation calls out to a third-party feed, which is why it is
    /// abstracted behind an interface and mocked (with Moq) during unit testing.
    /// </summary>
    public interface IDollarToEuroExchangeRateFeed
    {
        /// <summary>
        /// Returns the current number of Euros that one US Dollar is worth.
        /// </summary>
        double GetExchangeRate();
    }
}
