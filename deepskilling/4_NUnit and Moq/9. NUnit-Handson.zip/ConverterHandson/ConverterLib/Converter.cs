using System;

namespace ConverterLib
{
    /// <summary>
    /// Converts amounts between currencies. USDToEuro depends on an external
    /// exchange rate feed, which is injected so it can be substituted with a
    /// Moq mock during unit testing.
    /// </summary>
    public class Converter
    {
        private readonly IDollarToEuroExchangeRateFeed _exchangeRateFeed;

        public Converter(IDollarToEuroExchangeRateFeed exchangeRateFeed)
        {
            _exchangeRateFeed = exchangeRateFeed ?? throw new ArgumentNullException(nameof(exchangeRateFeed));
        }

        /// <summary>
        /// Converts a US Dollar amount to Euro using the current exchange rate
        /// obtained from the injected <see cref="IDollarToEuroExchangeRateFeed"/>.
        /// </summary>
        /// <param name="usdAmount">The amount in US Dollars. Must not be negative.</param>
        /// <exception cref="ArgumentException">Thrown when <paramref name="usdAmount"/> is negative.</exception>
        public double USDToEuro(double usdAmount)
        {
            if (usdAmount < 0)
            {
                throw new ArgumentException("USD amount cannot be negative.", nameof(usdAmount));
            }

            double exchangeRate = _exchangeRateFeed.GetExchangeRate();
            return usdAmount * exchangeRate;
        }
    }
}
