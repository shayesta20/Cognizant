using System;
using Moq;
using NUnit.Framework;
using ConverterLib;

namespace ConverterLib.Tests
{
    [TestFixture]
    public class ConverterTests
    {
        private Mock<IDollarToEuroExchangeRateFeed> _exchangeRateFeedMock;
        private Converter _converter;

        [SetUp]
        public void SetUp()
        {
            _exchangeRateFeedMock = new Mock<IDollarToEuroExchangeRateFeed>();
            _converter = new Converter(_exchangeRateFeedMock.Object);
        }

        // --- Happy path scenarios ---

        [Test]
        public void USDToEuro_ValidAmountWithKnownRate_ReturnsConvertedAmount()
        {
            _exchangeRateFeedMock.Setup(feed => feed.GetExchangeRate()).Returns(0.9);

            double result = _converter.USDToEuro(100);

            Assert.That(result, Is.EqualTo(90).Within(0.0001));
        }

        [Test]
        public void USDToEuro_ZeroAmount_ReturnsZero()
        {
            _exchangeRateFeedMock.Setup(feed => feed.GetExchangeRate()).Returns(0.9);

            double result = _converter.USDToEuro(0);

            Assert.That(result, Is.EqualTo(0));
        }

        [Test]
        public void USDToEuro_ValidAmount_CallsExchangeRateFeedExactlyOnce()
        {
            _exchangeRateFeedMock.Setup(feed => feed.GetExchangeRate()).Returns(0.9);

            _converter.USDToEuro(50);

            _exchangeRateFeedMock.Verify(feed => feed.GetExchangeRate(), Times.Once);
        }

        // --- Invalid input scenario ---

        [Test]
        public void USDToEuro_NegativeAmount_ThrowsArgumentException()
        {
            _exchangeRateFeedMock.Setup(feed => feed.GetExchangeRate()).Returns(0.9);

            Assert.That(() => _converter.USDToEuro(-10), Throws.TypeOf<ArgumentException>());
        }

        // --- Dependency behavior scenario ---

        [Test]
        public void USDToEuro_ExchangeRateFeedThrowsException_PropagatesException()
        {
            _exchangeRateFeedMock
                .Setup(feed => feed.GetExchangeRate())
                .Throws(new InvalidOperationException("Exchange rate feed is unavailable."));

            Assert.That(() => _converter.USDToEuro(100), Throws.TypeOf<InvalidOperationException>());
        }

        // --- Constructor guard scenario ---

        [Test]
        public void Constructor_NullExchangeRateFeed_ThrowsArgumentNullException()
        {
            Assert.That(() => new Converter(null!), Throws.TypeOf<ArgumentNullException>());
        }
    }
}
