# NUnit Hands-on — Calculator Unit Tests

A small solution for the NUnit hands-on exercise: a `Calculator` class in a class library, and an NUnit test project that covers it using `TestFixture`, `SetUp`, `TearDown`, `Test`, `TestCase`, and `Ignore`.

## What this covers

- Unit testing vs functional testing — a unit test targets the smallest piece of logic possible (here, one method) without pulling in the rest of the app.
- Loosely coupled, testable design — `Calculator` doesn't depend on any external class for its data, so it's easy to instantiate and test in isolation.
- `TestFixture` and `Test` attributes to define and run test cases.
- `SetUp` / `TearDown` for per-test initialization and cleanup.
- `Ignore` for a test that shouldn't run yet.
- `TestCase` for parameterised tests, so one method can validate several input/output combinations.
- `Assert.That` for the actual-vs-expected comparisons.

## Project structure

```
NUnit-Handson/
├── CalcLibrary/
│   └── Calculator.cs
└── CalculatorTests/
    └── CalculatorTests.cs
```

`CalcLibrary` is the class under test. `CalculatorTests` is a separate NUnit test project that references `CalcLibrary`.

## Calculator.cs

```csharp
namespace CalcLibrary
{
    public class Calculator
    {
        public double Add(double firstNumber, double secondNumber)
        {
            return firstNumber + secondNumber;
        }
    }
}
```

## CalculatorTests.cs

```csharp
using NUnit.Framework;
using CalcLibrary;

namespace CalculatorTests
{
    [TestFixture]
    public class CalculatorTests
    {
        private Calculator _calculator;

        [SetUp]
        public void Setup()
        {
            // Runs before every test - keeps each test isolated with a fresh instance
            _calculator = new Calculator();
        }

        [TearDown]
        public void TearDown()
        {
            // Runs after every test - cleans up so nothing leaks into the next run
            _calculator = null;
        }

        [Test]
        public void Add_TwoPositiveNumbers_ReturnsSum()
        {
            double result = _calculator.Add(5, 3);
            Assert.That(result, Is.EqualTo(8));
        }

        [TestCase(2, 3, 5)]
        [TestCase(-2, -3, -5)]
        [TestCase(0, 0, 0)]
        [TestCase(10.5, 4.5, 15)]
        [TestCase(-10, 10, 0)]
        public void Add_VariousInputs_ReturnsExpectedResult(double a, double b, double expected)
        {
            double result = _calculator.Add(a, b);
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test]
        [Ignore("Subtraction isn't part of CalcLibrary yet - enable once it's added")]
        public void Subtract_TwoNumbers_ReturnsDifference()
        {
            Assert.Fail("Not implemented");
        }
    }
}
```

## How to set it up in Visual Studio

1. Create a solution with two projects: a Class Library named `CalcLibrary` and an NUnit test project named `CalculatorTests`.
2. In `CalculatorTests`, add a project reference to `CalcLibrary`.
3. Install the NuGet packages `NUnit` and `NUnit3TestAdapter` in the test project (already included if you picked the "NUnit Test Project" template).
4. Drop `Calculator.cs` into `CalcLibrary` and `CalculatorTests.cs` into `CalculatorTests`.
5. Open Test Explorer and run all tests. `Add_TwoPositiveNumbers_ReturnsSum` and all five `TestCase` variations of `Add_VariousInputs_ReturnsExpectedResult` should pass. `Subtract_TwoNumbers_ReturnsDifference` will show as ignored, not failed.

## Notes

- `SetUp` and `TearDown` run around *every* test in the fixture, not once for the whole class — that's what `OneTimeSetUp` / `OneTimeTearDown` are for if you ever need it.
- `TestCase` lets you avoid copy-pasting near-identical test methods for every input combination — one method, several data rows.
- `Assert.That` is the constraint-model syntax NUnit recommends over the older `Assert.AreEqual` — it reads closer to plain English and composes better with constraints like `Is.EqualTo`, `Is.GreaterThan`, etc.
