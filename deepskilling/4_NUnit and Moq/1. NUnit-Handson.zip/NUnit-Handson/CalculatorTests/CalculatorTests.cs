using NUnit.Framework;
using CalcLibrary;

namespace CalculatorTests
{
    [TestFixture]
    public class CalculatorTests
    {
        private Calculator _calculator;

        [SetUp]
        public void Setup()
        {
            // Runs before every test - keeps each test isolated with a fresh instance
            _calculator = new Calculator();
        }

        [TearDown]
        public void TearDown()
        {
            // Runs after every test - cleans up so nothing leaks into the next run
            _calculator = null;
        }

        [Test]
        public void Add_TwoPositiveNumbers_ReturnsSum()
        {
            double result = _calculator.Add(5, 3);
            Assert.That(result, Is.EqualTo(8));
        }

        [TestCase(2, 3, 5)]
        [TestCase(-2, -3, -5)]
        [TestCase(0, 0, 0)]
        [TestCase(10.5, 4.5, 15)]
        [TestCase(-10, 10, 0)]
        public void Add_VariousInputs_ReturnsExpectedResult(double a, double b, double expected)
        {
            double result = _calculator.Add(a, b);
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test]
        [Ignore("Subtraction isn't part of CalcLibrary yet - enable once it's added")]
        public void Subtract_TwoNumbers_ReturnsDifference()
        {
            Assert.Fail("Not implemented");
        }
    }
}
