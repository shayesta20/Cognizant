using System;
using NUnit.Framework;
using AccountsManagerLib;

namespace AccountsManagerLib.Tests
{
    [TestFixture]
    public class AccountsManagerTests
    {
        private AccountsManager _accountsManager;

        [SetUp]
        public void Setup()
        {
            _accountsManager = new AccountsManager();
        }

        [Test]
        public void Login_ValidCredentials_ReturnsWelcomeMessage()
        {
            string result = _accountsManager.Login("user_11", "secret@user11");
            Assert.That(result, Is.EqualTo("Welcome user_11!!!"));
        }

        [Test]
        public void Login_InvalidPassword_ReturnsInvalidMessage()
        {
            string result = _accountsManager.Login("user_11", "wrongpassword");
            Assert.That(result, Is.EqualTo("Invalid user id/password"));
        }

        [Test]
        public void Login_UnknownUserId_ReturnsInvalidMessage()
        {
            string result = _accountsManager.Login("user_99", "secret@user11");
            Assert.That(result, Is.EqualTo("Invalid user id/password"));
        }

        [Test]
        public void Login_MissingUserId_ThrowsArgumentException()
        {
            Assert.That(() => _accountsManager.Login(string.Empty, "secret@user11"), Throws.ArgumentException);
        }

        [Test]
        public void Login_MissingPassword_ThrowsArgumentException()
        {
            Assert.That(() => _accountsManager.Login("user_11", string.Empty), Throws.ArgumentException);
        }
    }
}
