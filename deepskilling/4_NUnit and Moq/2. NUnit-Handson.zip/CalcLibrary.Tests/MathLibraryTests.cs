using NUnit.Framework;
using CalcLibrary;

namespace CalcLibrary.Tests
{
    [TestFixture]
    public class MathLibraryTests
    {
        private MathLibrary math;

        [SetUp]
        public void Setup()
        {
            math = new MathLibrary();
        }

        [TestCase(10, 5, 5)]
        [TestCase(20, 8, 12)]
        [TestCase(-10, -5, -5)]
        [TestCase(0, 5, -5)]
        public void TestSubtraction(double a, double b, double expected)
        {
            double actual = math.Subtraction(a, b);
            Assert.AreEqual(expected, actual);
        }

        [TestCase(2, 3, 6)]
        [TestCase(5, 0, 0)]
        [TestCase(-4, 5, -20)]
        [TestCase(-3, -3, 9)]
        public void TestMultiplication(double a, double b, double expected)
        {
            double actual = math.Multiplication(a, b);
            Assert.AreEqual(expected, actual);
        }

        [TestCase(10, 2, 5)]
        [TestCase(9, 3, 3)]
        [TestCase(-12, 4, -3)]
        public void TestDivision(double a, double b, double expected)
        {
            double actual = math.Division(a, b);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestDivisionByZero()
        {
            try
            {
                math.Division(10, 0);
                Assert.Fail("Division by zero");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Division by zero", ex.Message);
            }
        }

        [Test]
        public void TestAddAndClear()
        {
            double expected = 15;
            double actual = math.Addition(10, 5);
            Assert.AreEqual(expected, actual);

            math.AllClear();
            Assert.AreEqual(0, math.GetResult);
        }
    }
}
