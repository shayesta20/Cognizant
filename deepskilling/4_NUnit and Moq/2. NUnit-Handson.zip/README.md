# CalcLibrary - NUnit Hands-on

Simple calculator library with an NUnit test suite covering parameterized tests, void methods, and exception handling.

## Structure

- `CalcLibrary/MathLibrary.cs` - the calculator class (add, subtract, multiply, divide, clear)
- `CalcLibrary.Tests/MathLibraryTests.cs` - test fixture

## What's covered

- Parameterized tests for subtraction, multiplication, division using `[TestCase]`
- Divide by zero handled with try/catch + `Assert.Fail`
- Testing a void method (`AllClear`) by checking state before and after
- `Assert.AreEqual` used throughout to compare expected vs actual

## Running tests

```
dotnet test
```

## Notes

Private methods aren't tested directly here - they only exist to support a public method, so covering the public method covers them too. Testing private methods directly usually means reflection hacks or breaking encapsulation, neither of which is worth it.

For anything that depends on external stuff (DB, file system, etc.), use Moq instead of hitting the real thing:

```csharp
var mockRepo = new Mock<IDataRepository>();
mockRepo.Setup(r => r.GetValue()).Returns(42);

var service = new CalculatorService(mockRepo.Object);
var result = service.Process();

Assert.AreEqual(42, result);
```
