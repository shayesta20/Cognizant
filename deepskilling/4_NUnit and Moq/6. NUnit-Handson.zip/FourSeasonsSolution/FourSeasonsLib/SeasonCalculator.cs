using System;
using System.Collections.Generic;

namespace FourSeasonsLib
{
    /// <summary>
    /// Given a month name, returns the season that month falls in.
    ///
    ///   Spring  -> February, March
    ///   Summer  -> April, May, June
    ///   Monsoon -> July, August, September
    ///   Autumn  -> October, November
    ///   Winter  -> December, January
    /// </summary>
    public class SeasonCalculator
    {
        private static readonly Dictionary<string, string> MonthToSeason =
            new(StringComparer.OrdinalIgnoreCase)
            {
                { "January", "Winter" },
                { "February", "Spring" },
                { "March", "Spring" },
                { "April", "Summer" },
                { "May", "Summer" },
                { "June", "Summer" },
                { "July", "Monsoon" },
                { "August", "Monsoon" },
                { "September", "Monsoon" },
                { "October", "Autumn" },
                { "November", "Autumn" },
                { "December", "Winter" },
            };

        /// <summary>
        /// Returns the season name for the given month name.
        /// Throws ArgumentException if the month name is not recognized.
        /// </summary>
        public string GetSeason(string month)
        {
            if (month == null || !MonthToSeason.TryGetValue(month, out var season))
            {
                throw new ArgumentException($"'{month}' is not a valid month name.", nameof(month));
            }

            return season;
        }
    }
}
