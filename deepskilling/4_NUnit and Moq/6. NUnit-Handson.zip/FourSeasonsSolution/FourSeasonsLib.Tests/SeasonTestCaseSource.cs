using System.Collections;
using NUnit.Framework;

namespace FourSeasonsLib.Tests
{
    /// <summary>
    /// Alternate way of working with TestCaseSource: instead of a
    /// static member inside the test class, the data lives in its own
    /// class that implements IEnumerable. The test references it with
    /// [TestCaseSource(typeof(SeasonTestCaseSource))].
    /// </summary>
    public class SeasonTestCaseSource : IEnumerable
    {
        public IEnumerator GetEnumerator()
        {
            yield return new TestCaseData("February", "Spring").SetName("GetSeason_February_ReturnsSpring");
            yield return new TestCaseData("March", "Spring").SetName("GetSeason_March_ReturnsSpring");

            yield return new TestCaseData("April", "Summer").SetName("GetSeason_April_ReturnsSummer");
            yield return new TestCaseData("May", "Summer").SetName("GetSeason_May_ReturnsSummer");
            yield return new TestCaseData("June", "Summer").SetName("GetSeason_June_ReturnsSummer");

            yield return new TestCaseData("July", "Monsoon").SetName("GetSeason_July_ReturnsMonsoon");
            yield return new TestCaseData("August", "Monsoon").SetName("GetSeason_August_ReturnsMonsoon");
            yield return new TestCaseData("September", "Monsoon").SetName("GetSeason_September_ReturnsMonsoon");

            yield return new TestCaseData("October", "Autumn").SetName("GetSeason_October_ReturnsAutumn");
            yield return new TestCaseData("November", "Autumn").SetName("GetSeason_November_ReturnsAutumn");

            yield return new TestCaseData("December", "Winter").SetName("GetSeason_December_ReturnsWinter");
            yield return new TestCaseData("January", "Winter").SetName("GetSeason_January_ReturnsWinter");
        }
    }
}
