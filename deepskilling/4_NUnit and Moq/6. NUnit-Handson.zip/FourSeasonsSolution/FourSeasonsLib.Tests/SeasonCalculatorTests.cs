using System.Collections.Generic;
using FourSeasonsLib;
using NUnit.Framework;

namespace FourSeasonsLib.Tests
{
    [TestFixture]
    public class SeasonCalculatorTests
    {
        private SeasonCalculator _sut;

        [SetUp]
        public void Setup()
        {
            _sut = new SeasonCalculator();
        }

        // ---------------------------------------------------------------
        // Straightforward way: TestCaseSource points at a static member
        // (property) declared inside this same test class.
        // ---------------------------------------------------------------
        private static IEnumerable<TestCaseData> MonthSeasonCases
        {
            get
            {
                yield return new TestCaseData("February", "Spring");
                yield return new TestCaseData("March", "Spring");

                yield return new TestCaseData("April", "Summer");
                yield return new TestCaseData("May", "Summer");
                yield return new TestCaseData("June", "Summer");

                yield return new TestCaseData("July", "Monsoon");
                yield return new TestCaseData("August", "Monsoon");
                yield return new TestCaseData("September", "Monsoon");

                yield return new TestCaseData("October", "Autumn");
                yield return new TestCaseData("November", "Autumn");

                yield return new TestCaseData("December", "Winter");
                yield return new TestCaseData("January", "Winter");
            }
        }

        [TestCaseSource(nameof(MonthSeasonCases))]
        public void GetSeason_GivenMonth_ReturnsExpectedSeason(string month, string expectedSeason)
        {
            string result = _sut.GetSeason(month);

            Assert.That(result, Is.EqualTo(expectedSeason));
        }

        // ---------------------------------------------------------------
        // Alternate way: TestCaseSource points at a separate class that
        // implements IEnumerable (see SeasonTestCaseSource.cs).
        // ---------------------------------------------------------------
        [TestCaseSource(typeof(SeasonTestCaseSource))]
        public void GetSeason_GivenMonth_ReturnsExpectedSeason_AlternateSource(string month, string expectedSeason)
        {
            string result = _sut.GetSeason(month);

            Assert.That(result, Is.EqualTo(expectedSeason));
        }

        // ---------------------------------------------------------------
        // Invalid input handling
        // ---------------------------------------------------------------
        [TestCase("")]
        [TestCase("Foo")]
        [TestCase(null)]
        public void GetSeason_InvalidMonth_ThrowsArgumentException(string? month)
        {
            Assert.That(() => _sut.GetSeason(month!), Throws.ArgumentException);
        }
    }
}
