using System;

namespace LeapYearCalculatorLib
{
    /// <summary>
    /// Tells the caller whether a given year is a leap year, and validates
    /// that the year supplied falls within an accepted range.
    /// </summary>
    public class LeapYearCalculator
    {
        private const int MinValidYear = 1753;
        private const int MaxValidYear = 9999;

        /// <summary>
        /// Returns:
        ///   1  -> the year is a valid leap year
        ///   0  -> the year is valid but is NOT a leap year
        ///  -1  -> the year is outside the valid range (1753 - 9999 inclusive)
        /// </summary>
        public int CheckLeapYear(int year)
        {
            if (!IsValidYear(year))
            {
                return -1;
            }

            return DateTime.IsLeapYear(year) ? 1 : 0;
        }

        /// <summary>
        /// A year is valid only when it falls between 1753 and 9999 (inclusive).
        /// </summary>
        public bool IsValidYear(int year)
        {
            return year >= MinValidYear && year <= MaxValidYear;
        }
    }
}
