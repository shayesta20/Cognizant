using LeapYearCalculatorLib;
using NUnit.Framework;

namespace LeapYearCalculatorLib.Tests
{
    [TestFixture]
    public class LeapYearCalculatorTests
    {
        private LeapYearCalculator _sut;

        [SetUp]
        public void Setup()
        {
            _sut = new LeapYearCalculator();
        }

        // ---------- Leap year checks (parameterized) ----------

        [TestCase(2000)]   // divisible by 400 -> leap
        [TestCase(2004)]   // divisible by 4, not by 100 -> leap
        [TestCase(2020)]
        [TestCase(2400)]
        public void CheckLeapYear_ValidLeapYear_ReturnsOne(int year)
        {
            int result = _sut.CheckLeapYear(year);

            Assert.That(result, Is.EqualTo(1));
        }

        [TestCase(1900)]   // divisible by 100, not by 400 -> not leap
        [TestCase(2001)]
        [TestCase(2100)]
        [TestCase(2023)]
        public void CheckLeapYear_ValidNonLeapYear_ReturnsZero(int year)
        {
            int result = _sut.CheckLeapYear(year);

            Assert.That(result, Is.EqualTo(0));
        }

        // ---------- Boundary / validity checks ----------

        [TestCase(1753)]   // lower boundary, inclusive
        [TestCase(9999)]   // upper boundary, inclusive
        public void CheckLeapYear_YearOnBoundary_ReturnsValidResult(int year)
        {
            int result = _sut.CheckLeapYear(year);

            Assert.That(result, Is.Not.EqualTo(-1));
        }

        [TestCase(1752)]   // just below lower boundary
        [TestCase(0)]
        [TestCase(-500)]
        public void CheckLeapYear_YearBelowValidRange_ReturnsMinusOne(int year)
        {
            int result = _sut.CheckLeapYear(year);

            Assert.That(result, Is.EqualTo(-1));
        }

        [TestCase(10000)]  // just above upper boundary
        [TestCase(50000)]
        public void CheckLeapYear_YearAboveValidRange_ReturnsMinusOne(int year)
        {
            int result = _sut.CheckLeapYear(year);

            Assert.That(result, Is.EqualTo(-1));
        }

        // ---------- IsValidYear checks ----------

        [TestCase(1753)]
        [TestCase(2024)]
        [TestCase(9999)]
        public void IsValidYear_YearWithinRange_ReturnsTrue(int year)
        {
            bool result = _sut.IsValidYear(year);

            Assert.That(result, Is.True);
        }

        [TestCase(1752)]
        [TestCase(10000)]
        public void IsValidYear_YearOutsideRange_ReturnsFalse(int year)
        {
            bool result = _sut.IsValidYear(year);

            Assert.That(result, Is.False);
        }
    }
}
