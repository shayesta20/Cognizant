using System;

namespace UtilLib
{
    /// <summary>
    /// Parses the host name out of a URL.
    /// The function has two execution paths:
    ///   1) The input already contains a scheme (e.g. "http://", "https://", "ftp://")
    ///      -> the .NET Uri class is used to extract the host.
    ///   2) The input does NOT contain a scheme (e.g. "www.example.com/path" or "example.com:8080")
    ///      -> the host name is extracted manually by stripping the path and port.
    /// </summary>
    public class UrlHostNameParser
    {
        public string ParseHostName(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentException("URL cannot be null, empty, or whitespace.", nameof(url));
            }

            string trimmedUrl = url.Trim();

            // Execution path 1: URL contains a scheme, e.g. "http://www.example.com/path"
            if (trimmedUrl.Contains("://"))
            {
                Uri uri = new Uri(trimmedUrl);
                return uri.Host;
            }

            // Execution path 2: URL does not contain a scheme, e.g. "www.example.com/path" or "example.com:8080"
            string hostPart = trimmedUrl;

            int slashIndex = hostPart.IndexOf('/');
            if (slashIndex > -1)
            {
                hostPart = hostPart.Substring(0, slashIndex);
            }

            int colonIndex = hostPart.IndexOf(':');
            if (colonIndex > -1)
            {
                hostPart = hostPart.Substring(0, colonIndex);
            }

            return hostPart;
        }
    }
}
