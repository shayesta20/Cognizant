using System;
using NUnit.Framework;
using UtilLib;

namespace UtilLib.Tests
{
    [TestFixture]
    public class UrlHostNameParserTests
    {
        private UrlHostNameParser _parser;

        [SetUp]
        public void SetUp()
        {
            _parser = new UrlHostNameParser();
        }

        // --- Execution path 1: URL contains a scheme ---

        [Test]
        public void ParseHostName_HttpUrlWithScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("http://www.example.com/path/page.html");

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_HttpsUrlWithScheme_ReturnsHostName()
        {
            string result = _parser.ParseHostName("https://secure.example.com/login");

            Assert.That(result, Is.EqualTo("secure.example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithSchemeAndPort_ReturnsHostNameWithoutPort()
        {
            string result = _parser.ParseHostName("http://www.example.com:8080/path");

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithSchemeAndNoPath_ReturnsHostName()
        {
            string result = _parser.ParseHostName("https://example.com");

            Assert.That(result, Is.EqualTo("example.com"));
        }

        // --- Execution path 2: URL without a scheme ---

        [Test]
        public void ParseHostName_UrlWithoutSchemeWithPath_ReturnsHostName()
        {
            string result = _parser.ParseHostName("www.example.com/path/page.html");

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithoutSchemeWithPort_ReturnsHostNameWithoutPort()
        {
            string result = _parser.ParseHostName("example.com:8080");

            Assert.That(result, Is.EqualTo("example.com"));
        }

        [Test]
        public void ParseHostName_UrlWithoutSchemeNoPathNoPort_ReturnsHostName()
        {
            string result = _parser.ParseHostName("example.com");

            Assert.That(result, Is.EqualTo("example.com"));
        }

        // --- Invalid input handling ---

        [Test]
        public void ParseHostName_NullUrl_ThrowsArgumentException()
        {
            Assert.That(() => _parser.ParseHostName(null!), Throws.ArgumentException);
        }

        [Test]
        public void ParseHostName_EmptyUrl_ThrowsArgumentException()
        {
            Assert.That(() => _parser.ParseHostName(string.Empty), Throws.ArgumentException);
        }

        [Test]
        public void ParseHostName_WhitespaceUrl_ThrowsArgumentException()
        {
            Assert.That(() => _parser.ParseHostName("   "), Throws.ArgumentException);
        }
    }
}
