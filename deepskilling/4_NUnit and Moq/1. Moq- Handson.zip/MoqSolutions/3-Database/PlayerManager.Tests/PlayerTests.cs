using Moq;
using NUnit.Framework;
using PlayersManagerLib;

namespace PlayerManager.Tests
{
    [TestFixture]
    public class PlayerTests
    {
        private Mock<IPlayerMapper> _mockPlayerMapper;

        [OneTimeSetUp]
        public void Init()
        {
            _mockPlayerMapper = new Mock<IPlayerMapper>();
            _mockPlayerMapper
                .Setup(m => m.IsPlayerNameExistsInDb(It.IsAny<string>()))
                .Returns(false);
            _mockPlayerMapper
                .Setup(m => m.AddNewPlayerIntoDb(It.IsAny<string>()));
        }

        [TestCase]
        public void RegisterNewPlayer_ValidName_ReturnsPlayerWithExpectedAttributes()
        {
            var player = Player.RegisterNewPlayer("Virat", _mockPlayerMapper.Object);

            Assert.That(player.Name, Is.EqualTo("Virat"));
            Assert.That(player.Age, Is.EqualTo(23));
            Assert.That(player.Country, Is.EqualTo("India"));
            Assert.That(player.NoOfMatches, Is.EqualTo(30));
        }

        [TestCase]
        public void RegisterNewPlayer_EmptyName_ThrowsArgumentException()
        {
            Assert.Throws<System.ArgumentException>(
                () => Player.RegisterNewPlayer("", _mockPlayerMapper.Object));
        }

        [TestCase]
        public void RegisterNewPlayer_NameAlreadyExists_ThrowsArgumentException()
        {
            var mapperWithExistingName = new Mock<IPlayerMapper>();
            mapperWithExistingName
                .Setup(m => m.IsPlayerNameExistsInDb(It.IsAny<string>()))
                .Returns(true);

            Assert.Throws<System.ArgumentException>(
                () => Player.RegisterNewPlayer("Virat", mapperWithExistingName.Object));
        }
    }
}
