using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using MagicFilesLib;

namespace DirectoryExplorer.Tests
{
    [TestFixture]
    public class DirectoryExplorerTests
    {
        private readonly string _file1 = "file.txt";
        private readonly string _file2 = "file2.txt";

        private Mock<IDirectoryExplorer> _mockExplorer;

        [OneTimeSetUp]
        public void Init()
        {
            _mockExplorer = new Mock<IDirectoryExplorer>();

            ICollection<string> fakeFiles = new List<string> { _file1, _file2 };

            _mockExplorer
                .Setup(m => m.GetFiles(It.IsAny<string>()))
                .Returns(fakeFiles);
        }

        [TestCase]
        public void GetFiles_ReturnsExpectedCollection()
        {
            var result = _mockExplorer.Object.GetFiles(@"C:\SomePath");

            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count, Is.EqualTo(2));
            Assert.That(result, Does.Contain(_file1));
        }
    }
}
