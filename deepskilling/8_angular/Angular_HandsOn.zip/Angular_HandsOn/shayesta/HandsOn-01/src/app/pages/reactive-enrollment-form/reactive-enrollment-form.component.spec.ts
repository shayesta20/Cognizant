import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveEnrollmentFormComponent, noCourseCode } from './reactive-enrollment-form.component';
import { FormControl } from '@angular/forms';

describe('ReactiveEnrollmentFormComponent', () => {
  let fixture: ComponentFixture<ReactiveEnrollmentFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveEnrollmentFormComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(ReactiveEnrollmentFormComponent);
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('noCourseCode rejects codes starting with XX', () => {
    expect(noCourseCode(new FormControl('XX101'))).toEqual({ noCourseCode: true });
    expect(noCourseCode(new FormControl('CS101'))).toBeNull();
  });
});
