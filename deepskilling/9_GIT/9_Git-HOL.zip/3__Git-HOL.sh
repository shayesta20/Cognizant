#!/bin/bash
# ============================================================
# 3__Git-HOL.sh
# Objective : Branching and merging - create a branch, make
#             changes, merge back to master/trunk using P4Merge
# Run in    : Git Bash, inside an existing Git repository (GitDemo)
# ============================================================

cd GitDemo || { echo "GitDemo repository not found"; exit 1; }

# ---------------------- BRANCHING ----------------------

# 1. Create a new branch "GitNewBranch"
git branch GitNewBranch

# 2. List all local and remote branches (the "*" marks the current branch)
git branch -a

# 3. Switch to the newly created branch
git checkout GitNewBranch

#    Add some files with content
echo "This is a file created in GitNewBranch" > branchfile.txt
echo "Second line of content" >> branchfile.txt

# 4. Commit the changes to the branch
git add branchfile.txt
git commit -m "Add branchfile.txt in GitNewBranch"

# 5. Check status
git status

# ---------------------- MERGING ----------------------

# 1. Switch back to master
git checkout master

# 2. List all differences between master (trunk) and GitNewBranch (CLI)
git diff master GitNewBranch

# 3. List all visual differences using the P4Merge tool
git difftool -t p4merge master GitNewBranch

# 4. Merge the source branch (GitNewBranch) into master (trunk)
git merge GitNewBranch

# 5. Observe the log after merging
git log --oneline --graph --decorate

# 6. Delete the branch after it has been merged, and observe status
git branch -d GitNewBranch
git status
