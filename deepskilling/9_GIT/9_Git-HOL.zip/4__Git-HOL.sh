#!/bin/bash
# ============================================================
# 4__Git-HOL.sh
# Objective : Resolve merge conflicts that arise when master and
#             a branch modify the same file differently
# Prereq    : Git-T03-HOL_001 (branching/merging lab) completed
# Run in    : Git Bash, inside an existing Git repository (GitDemo)
# ============================================================

cd GitDemo || { echo "GitDemo repository not found"; exit 1; }

# 1. Verify master is in a clean state
git checkout master
git status

# 2. Create a branch "GitWork" and add a file "hello.xml"
git branch GitWork
git checkout GitWork
cat > hello.xml <<'EOF'
<greeting>
    <message>Hello from GitWork branch</message>
</greeting>
EOF
git add hello.xml
git commit -m "Add hello.xml in GitWork branch"

# 3. Update the content of hello.xml and observe status
cat > hello.xml <<'EOF'
<greeting>
    <message>Hello from GitWork branch - updated</message>
</greeting>
EOF
git status

# 4. Commit the changes to reflect in the branch
git add hello.xml
git commit -m "Update hello.xml content in GitWork branch"

# 5. Switch to master
git checkout master

# 6. Add a file "hello.xml" to master with different content
cat > hello.xml <<'EOF'
<greeting>
    <message>Hello from master branch</message>
</greeting>
EOF

# 7. Commit the changes to master
git add hello.xml
git commit -m "Add hello.xml in master branch with different content"

# 8. Observe the log
git log --oneline --graph --decorate --all

# 9. Check differences with the Git diff tool
git diff master GitWork -- hello.xml

# 10. Use P4Merge tool to visualize differences between master and branch
git difftool -t p4merge master GitWork -- hello.xml

# 11. Merge the branch into master (this will raise a conflict)
git merge GitWork

# 12. Observe the git conflict markup in hello.xml
cat hello.xml
git status

# 13. Use the 3-way merge tool (P4Merge) to resolve the conflict
git mergetool -t p4merge

# 14. Commit the changes to master once the conflict is resolved
git add hello.xml
git commit -m "Resolve merge conflict in hello.xml between master and GitWork"

# 15. Observe git status and add backup file created by mergetool to .gitignore
git status
echo "*.orig" >> .gitignore

# 16. Commit the changes to .gitignore
git add .gitignore
git commit -m "Ignore .orig backup files created by merge tool"

# 17. List all available branches
git branch -a

# 18. Delete the branch that was merged into master
git branch -d GitWork

# 19. Observe the final log
git log --oneline --graph --decorate
