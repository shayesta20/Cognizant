#!/bin/bash
# ============================================================
# 1__Git-HOL.sh
# Objective : Git configuration, notepad++ integration as default
#             editor, and adding the first file to the repository.
# Run in    : Git Bash
# ============================================================

# --------- Step 1: Setup machine with Git configuration ---------

# 1. Verify Git client is installed
git --version

# 2. Configure user level Git configuration (name and email)
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 3. Verify configuration is set properly
git config --list

# --------- Step 2: Integrate notepad++.exe as default editor ---------

# 1. Check if notepad++ runs from Git bash (fails if not on PATH)
notepad++

# NOTE: If the above fails, add the notepad++ installation folder
# (e.g. C:\Program Files\Notepad++) to the "Path" user environment
# variable via Control Panel -> System -> Advanced System Settings
# -> Environment Variables, then restart Git Bash.

# 2. After adding to PATH, re-run to confirm it opens
notepad++

# 3. Create an alias for notepad++ (add this line to ~/.bashrc)
echo "alias notepad++='/c/Program\ Files/Notepad++/notepad++.exe'" >> ~/.bashrc
source ~/.bashrc

# 4. Configure notepad++ as the default Git editor
git config --global core.editor "notepad++ -multiInst -notabbar -nosession -noPlugin"

# 5. Verify notepad++ is set as the default editor
git config --global -e
git config --list

# --------- Step 3: Add a file to the source code repository ---------

# 1. Create a new project/repository "GitDemo"
mkdir -p GitDemo
cd GitDemo

# 2. Initialize the Git repository and verify hidden .git folder
git init
ls -la

# 3. Create a file "welcome.txt" with content
echo "Welcome to Git Hands-On Lab" > welcome.txt

# 4. Verify the file was created
ls -la

# 5. Verify the content of the file
cat welcome.txt

# 6. Check status of the working directory
git status

# 7. Stage/track the file with Git
git add welcome.txt

# 8. Add a multi-line commit message using the default editor
git commit

# 9. Verify local repository and working directory are in sync
git status

# 10. Create/connect the remote repository "GitDemo" in GitLab
git remote add origin https://gitlab.com/<your-username>/GitDemo.git

# 11. Pull from the remote repository
git pull origin master

# 12. Push the local repository to the remote repository
git push origin master
