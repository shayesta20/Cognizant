#!/bin/bash
# ============================================================
# 5__Git-HOL.sh
# Objective : Clean up local repository and push pending changes
#             back to the remote Git repository
# Prereq    : Git-T03-HOL_002 (merge conflict resolution lab) completed
# Run in    : Git Bash, inside an existing Git repository (GitDemo)
# ============================================================

cd GitDemo || { echo "GitDemo repository not found"; exit 1; }

# 1. Verify master is in a clean state
git checkout master
git status

# 2. List out all available branches
git branch -a

# 3. Pull the remote Git repository into master
git pull origin master

# 4. Push the changes pending from Git-T03-HOL_002 to the remote repository
git push origin master

# 5. Verify the changes are reflected in the remote repository
git log origin/master --oneline --graph --decorate
git remote show origin
