#!/bin/bash
# ============================================================
# 2__Git-HOL.sh
# Objective : Ignore unwanted files/folders (e.g. *.log and a
#             "log" folder) using .gitignore
# Run in    : Git Bash, inside an existing Git repository (GitDemo)
# ============================================================

cd GitDemo || { echo "GitDemo repository not found"; exit 1; }

# 1. Create a ".log" file in the working directory
echo "sample log entry" > app.log

# 2. Create a "log" folder with a sample file inside it
mkdir -p log
echo "sample log file" > log/debug.log

# 3. Check current status - both app.log and log/ show as untracked
git status

# 4. Create/update the .gitignore file to ignore .log files and the log folder
cat >> .gitignore <<'EOF'
# Ignore all log files
*.log

# Ignore the log folder entirely
log/
EOF

# 5. Verify .gitignore content
cat .gitignore

# 6. Check git status again - app.log and log/ should no longer be listed
#    as untracked; only .gitignore will show as a new/modified file
git status

# 7. Stage and commit the .gitignore file itself
git add .gitignore
git commit -m "Add .gitignore to ignore .log files and log folder"

# 8. Final verification of working directory, staging area and repo state
git status
