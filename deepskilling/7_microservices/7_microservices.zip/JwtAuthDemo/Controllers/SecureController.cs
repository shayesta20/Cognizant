using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JwtAuthDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SecureController : ControllerBase
    {
        [HttpGet("data")]
        [Authorize] // Requires a valid JWT bearer token in the Authorization header
        public IActionResult GetSecureData()
        {
            var username = User.Identity?.Name;
            return Ok(new
            {
                Message = "This is protected data.",
                RequestedBy = username
            });
        }
    }
}
